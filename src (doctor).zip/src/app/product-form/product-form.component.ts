import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProductServiceService } from '../product-service.service';
import { Product } from '../../Model/product';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.css'
})
export class ProductFormComponent {

  constructor(private productService:ProductServiceService,
    private router:Router) {}
  productForm: Product = {
    id: 0,
    pname: '',
    price: 0
  };
 
  create(){
    this.productService.createProduct(this.productForm)
    .subscribe({
      next:(data) => {
        this.router.navigate(["/Products"])
      },
      error:(err: any) => {
        console.log(err);
      }
    })
  }

}
