import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ProductComponent } from './product/product.component';
import { HomeComponent } from './home/home.component';
import { ProductFormComponent } from './product-form/product-form.component';
import { ProductEditComponent } from './product-edit/product-edit.component';

const routes: Routes = [
{ path: 'Home', component: HomeComponent },
{path : 'Login', component:LoginComponent},
{path : 'Product', component:ProductComponent},
{path:'New', component:ProductFormComponent},
{ path: 'Edit/:id', component: ProductEditComponent},
 {path:'', redirectTo:'Products',pathMatch:'full'},
{ path: '**', component:  LoginComponent }




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
