//------Arrays ----------
//---Using square brackets
var departments = ['Hr', 'Finanace', 'Sales'];
console.log('List of Departments: ' + departments);
//---Using Generic Type
var depts = ['Hr', 'Finanace', 'Sales'];
console.log('List of Depts: ' + depts);
//---Declaration adn Definition
var city;
city = ['Pune', 'Calcutta', 'Mumbai'];
//-----MultiType Array
var days = ['Monday', 2, 'Tuesday', 4];
console.log(days);
var month = ['Jan', 2, 3, 'Feb', 5];
console.log(month);
