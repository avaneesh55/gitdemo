

let user:String;
user = "Shaitesh";
console.log(typeof user);
console.log(user);
console.log(user.toUpperCase());
let num1:number=123;
let num2:number=23453;

function myfun(num1:number,num2:number):number{
let num:number=num1+num2;
return num;

}
console.log(myfun(num1,num2));
let user1:String="Shailesh";
let user2:String="avaneesh@123";

let array:number[] =[12,14,18,20,10];
console.log(array);

console.log(typeof array);
console.log(array[2]);
array.forEach((l)=>{

console.log(l);

});

let friends:String[]= ["Shailesh","Ramesh","Mohan","Jeetu"]; 
console.log(friends.toString());


 let newarray=friends.map((value)=>{


if(value=="Ramesh"){
return value.toLowerCase();
}else{
return value.toUpperCase()
}
console.log(value);

}); 
console.log(newarray);


let new1=friends.forEach((value)=>{

    console.log(value);
    return value.toUpperCase["shailesh"];
    
    }); 
    console.log(new1);

    let student:object={
     


    }



   





