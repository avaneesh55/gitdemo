package filehandling;

public class Employee {
	
   public String id;
   public String name;
   public String department;
   private double salary;
public Employee(String id, String name, String department, double salary) {
	super();
	this.id = id;
	this.name = name;
	this.department = department;
	this.salary = salary;
}
   
   
   
   
}
